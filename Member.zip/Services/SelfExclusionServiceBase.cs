﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Member.Interfaces;

namespace Member.Services
{
    public class SelfExclusionServiceDependency
    {
        public readonly ISelfExclusionRepository _SelfExclusionRepository;
        public SelfExclusionServiceDependency(ISelfExclusionRepository selfExclusionRepository)
        {
            this._SelfExclusionRepository = selfExclusionRepository;
        }
    }
    public class SelfExclusionServiceBase
    {
        public SelfExclusionServiceDependency _SelfExclusionServiceDependency;
        public SelfExclusionServiceBase(SelfExclusionServiceDependency selfExclusionServiceDependency)
        {
            this._SelfExclusionServiceDependency = selfExclusionServiceDependency;
        }
        /// <summary>
        /// Check if the member has self-exclusion.
        /// </summary>
        /// <param name="userName">Username.</param>
        /// <returns></returns>
        public bool CheckHasSelfExclusion(string userName)
        {
            var result = this._SelfExclusionServiceDependency._SelfExclusionRepository.GetSelfExclusion(userName);
            return !string.IsNullOrEmpty(result);
        }

        /// <summary>
        /// Create Self-exclusion.
        /// </summary>
        /// <param name="userName">Username</param>
        public string CreateSelfExclusion(string userName)
        {
            if (this.CheckHasSelfExclusion(userName))
            {
                return "User already has self-exclusion.";
            }
           return this._SelfExclusionServiceDependency._SelfExclusionRepository.InsertSelfExclusion(userName);
        }
    }
}

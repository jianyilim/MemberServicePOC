﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Dynamic;
using Member.Interfaces;
using Member.Models;
using System.Text.RegularExpressions;

namespace Member.Services
{
    public class MemberServiceDependency
    {
        public readonly IMemberRepository _MemberRepository;
        public readonly SelfExclusionServiceBase _SelfExclusionService;
        public MemberServiceDependency(IMemberRepository iMemberRepository, SelfExclusionServiceBase selfExclusionService)
        {
            this._MemberRepository = iMemberRepository;
            this._SelfExclusionService = selfExclusionService;
        }
    }

    public class MemberServiceBase
    {
        public readonly MemberServiceDependency _MemberServiceDependency;
        public MemberServiceBase(MemberServiceDependency memberServiceDependency)
        {
            this._MemberServiceDependency = memberServiceDependency;
        }
    
        public virtual bool RegisterNewMember(UserModel user, out string result)
        {
            result = "";
            if (this.ValidateNewUser(user, out result))
            {
                result = this._MemberServiceDependency._MemberRepository.InsertNewMember(user);
                return true;
            }
            else
                return false;
            
        }
        public virtual string UpdateMember(UserModel user)
        {
            if (this.Login(user) is null)
            {
                return "Invalid login";
            }
            else return this._MemberServiceDependency._MemberRepository.UpdateMember(user);

        }
        public virtual UserModel Login(UserModel user)
        {

            if (!this._MemberServiceDependency._SelfExclusionService.CheckHasSelfExclusion(user.Username))
                user = this.ValidateLoginCredential(user);
            else
                user = null;
          
           return user;
        }
        public virtual UserModel ValidateLoginCredential(UserModel user)
        {
            return this._MemberServiceDependency._MemberRepository.Login(user.Username, user.Password);
        }
        public bool VerifyPassword(string password)
        {
            return !string.IsNullOrEmpty(password) && Regex.Match(password, this.GetPasswordRegex()).Success;
        }

        public string GetPasswordRegex()
        {
            return "^(?=.*[0-9]+.*)(?=.*[a-zA-Z]+.*)[0-9a-zA-Z]{6,}$";
        }

        public bool ValidateNewUser(UserModel user, out string resultstring)
        {
            resultstring = string.Empty;
            if (this._MemberServiceDependency._MemberRepository.CheckMemberExists(user.Username))
            {
                resultstring = "Member exists";
                return false;
            }
            else if (!this.VerifyPassword(user.Password))
            {
                resultstring = "Weak password.";
                return false;
            }
            return true;
        }
    }
}

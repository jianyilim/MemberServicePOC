﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Member.Services;
using Microsoft.Extensions.DependencyInjection;
using Member.Factories;

namespace Member.Factories
{
    class BUCode
    {
        public static readonly string Betway = "BETWAY";
        public static readonly string RB88 = "RB88";
    }
    public abstract class MemberFactory
    {
        /// <summary>
        /// Create an instance of MemberFactory based on brand.
        /// </summary>
        /// <param name="buCode">Business unit code.</param>
        /// <returns>MemberFactory</returns>
        public static MemberFactory CreateMemberFactory(string buCode)
        {
            MemberFactory memberFactory = null;
            if (buCode == BUCode.Betway)
                memberFactory = new MemberFactoryBetway();
            return memberFactory;
        }
        /// <summary>
        /// Create an instance of MemberService based on brand and project flag.
        /// </summary>
        /// <param name="buCode">Business unit code.</param>
        /// <param name="flag">Project flag. Either 1,2 or 3.</param>
        /// <returns>MemberServiceBase</returns>
        public static MemberServiceBase CreateMemberService(string buCode, int flag)
        {
            return MemberFactory.CreateMemberFactory(buCode).CreateMemberService(flag);
        }

        /// <summary>
        /// Create an instance of SelfExclusionService based on brand and project flag.
        /// </summary>
        /// <param name="buCode">Business unit code.</param>
        /// <param name="flag">Project flag. Either 1,2 or 3.</param>
        /// <returns>SelfExclusionServiceBase</returns>
        public static SelfExclusionServiceBase CreateSelfExclusionService(string buCode, int flag)
        {
            return MemberFactory.CreateMemberFactory(buCode).CreateSelfExclusionService(flag);
        }
        /// <summary>
        /// Create an instance of MemberService based on brand and project flag.
        /// </summary>
        /// <param name="flag">Project flag. Either 1,2 or 3.</param>
        /// <returns>MemberServiceBase</returns>
        public abstract MemberServiceBase CreateMemberService(int flag);

        /// <summary>
        /// Create an instance of SelfExclusionService based on brand and project flag.
        /// </summary>
        /// <param name="flag">Project flag. Either 1,2 or 3.</param>
        /// <returns>SelfExclusionServiceBase</returns>
        public abstract SelfExclusionServiceBase CreateSelfExclusionService(int flag);

        public static void ConfigureServices(string buCode, IServiceCollection services)
        {
            MemberFactory memberFactory = null;

            if (buCode == BUCode.Betway)
            {
                memberFactory = new MemberFactoryBetway();
            }

            memberFactory.ConfigureServices(services);
        }
        public abstract void ConfigureServices(IServiceCollection services);
    }
}

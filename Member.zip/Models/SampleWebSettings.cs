﻿namespace Member.Models
{
    #region snippet
    public class SampleWebSettings
    {
        public string Title { get; set; }
        public int Updates { get; set; }

        public int _ProjectFlag { get; set; }
        public string _BUCode { get; set; }
    }
    #endregion
}

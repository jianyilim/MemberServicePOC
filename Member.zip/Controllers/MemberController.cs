﻿using Member.Interfaces;
using Member.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using System.Diagnostics;
using Member.Factories;
using Member.Services;
using System.Linq;

namespace Member.Controllers
{
    public class MemberController : Controller
    {

        public MemberController()
        {
        }

        public IActionResult Index()
        {
            var member = new Models.UserModel()
            {
                Username = "Test"
            };
            return View(member);
        }
        /// <summary>
        /// Register new member.
        /// </summary>
        /// <param name="memberService">Member service from services.</param>
        /// <param name="usermodel">User model from view.</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult RegisterNewMember([FromServices]MemberServiceBase memberService, UserModel usermodel)
        {
            string message = "";
            memberService.RegisterNewMember(usermodel, out message);
            ViewBag.Message = message;
            return View("Index");
        }

        /// <summary>
        /// Update member detail.
        /// </summary>
        /// <param name="memberService">Member service from services.</param>
        /// <param name="usermodel">User model from view.</param>
        /// <returns></returns>
        [HttpPost]
        public IActionResult UpdateMember([FromServices] MemberServiceBase memberService, UserModel usermodel)
        {
            ViewBag.Message = memberService.UpdateMember(usermodel);
            return View("Index");
        }


        /// <summary>
        /// User login.
        /// </summary>
        /// <param name="userName">Username.</param>
        /// <param name="password">Password.</param>
        /// <returns>True if login successful.</returns>
        [HttpPost]
        public IActionResult Login([FromServices]MemberServiceBase memberService, UserModel usermodel)
        {
            usermodel = memberService.Login(usermodel);
            if (usermodel is null)
                ViewBag.Message = "Login failed!";
            return View("Index", usermodel);
        }

        /// <summary>
        /// Check if a user has self-exclusion set.
        /// </summary>
        /// <param name="userName">Username.</param>
        /// <returns>True if the user has self-exclusion set.</returns>
        [HttpPost]
        public IActionResult CheckSelfExclusion([FromServices]SelfExclusionServiceBase selfExclusionService, UserModel usermodel)
        {
            ViewBag.Message = "Has self-exclusion = " + selfExclusionService.CheckHasSelfExclusion(usermodel.Username);
            return View("Index");
        }

        /// <summary>
        /// Create Self-exclusion.
        /// </summary>
        /// <param name="userName">Username.</param>
        [HttpPost]
        public IActionResult CreateSelfExclusion([FromServices] SelfExclusionServiceBase selfExclusionService, UserModel usermodel)
        {
            ViewBag.Message = selfExclusionService.CreateSelfExclusion(usermodel.Username);
            return View("Index");
        }
    }
}

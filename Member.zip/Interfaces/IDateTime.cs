﻿using System;

namespace Member.Interfaces
{
    #region snippet
    public interface IDateTime
    {
        DateTime Now { get; }
    }
    #endregion
}

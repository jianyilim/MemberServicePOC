﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Member.Services
{
    public class SelfExclusionServiceBetway : SelfExclusionServiceBase
    {
        public SelfExclusionServiceBetway(SelfExclusionServiceDependency selfExclusionServiceDependency) : base(selfExclusionServiceDependency)
        {
        }

    }
}

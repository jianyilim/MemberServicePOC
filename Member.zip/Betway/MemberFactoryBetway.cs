﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Member.Services;
using Member.Repositories;
using Member.Interfaces;
using Microsoft.Extensions.DependencyInjection;

namespace Member.Factories
{
    public class MemberFactoryBetway : MemberFactory
    {
        public override void ConfigureServices(IServiceCollection services)
        {
            var flag = Member.Controllers.SettingsController._GlobalSettings._ProjectFlag;

            services.AddScoped<SelfExclusionServiceBase, SelfExclusionServiceBetway>();
            services.AddScoped<ISelfExclusionRepository, SelfExclusionRepositoryNettium>();
            services.AddScoped<SelfExclusionServiceDependency, SelfExclusionServiceDependency>();
            if (flag == 1)
            {
                services.AddScoped<MemberServiceBase, MemberServiceBetwayFlag1>();
                services.AddScoped<MemberServiceBetwayFlag1Dependency, MemberServiceBetwayFlag1Dependency>();
                services.AddScoped<IMemberRepository, MemberRepositoryFunpodium>();
                services.AddScoped<IMemberRepositorySecondary, MemberRepositoryNettium>();
            }
            else if (flag == 2)
            {
                services.AddScoped<MemberServiceBase, MemberServiceBetwayFlag2>();
                services.AddScoped<MemberServiceDependency, MemberServiceDependency>();
                services.AddScoped<IMemberRepository, MemberRepositoryNettium>();
            }
            else if (flag == 3)
            {
                services.AddScoped<MemberServiceBase, MemberServiceBetwayFlag3>();
                services.AddScoped<MemberServiceDependency, MemberServiceDependency>();
                services.AddScoped<IMemberRepository, MemberRepositoryFunpodium>();
            }

        }

        public override MemberServiceBase CreateMemberService(int flag)
        {
            MemberServiceBase memberService = null;
            SelfExclusionServiceBase selfExclusionService = this.CreateSelfExclusionService(flag);
            if (flag == 1)
            {
                var  memberServiceDependencyFlag1 = new MemberServiceBetwayFlag1Dependency(new MemberRepositoryFunpodium(), selfExclusionService, new MemberRepositoryNettium());
                memberService = new MemberServiceBetwayFlag1(memberServiceDependencyFlag1);
            }
            else if (flag == 2)
            {
                var memberServiceDependency = new MemberServiceDependency(new MemberRepositoryNettium(), selfExclusionService);
                memberService = new MemberServiceBetwayFlag2(memberServiceDependency);
            }
            else
            {
                var  memberServiceDependency = new MemberServiceDependency(new MemberRepositoryFunpodium(), selfExclusionService);
                memberService = new MemberServiceBetwayFlag3(memberServiceDependency);
            }

            return memberService;
        }

        public override SelfExclusionServiceBase CreateSelfExclusionService(int flag)
        {
            var selfExclusionServiceDependency = new SelfExclusionServiceDependency(new SelfExclusionRepositoryNettium());
            var selfExclusionServiceBase = new SelfExclusionServiceBetway(selfExclusionServiceDependency);
            selfExclusionServiceBase._SelfExclusionServiceDependency = selfExclusionServiceDependency;

            return selfExclusionServiceBase;
        }
    }
}

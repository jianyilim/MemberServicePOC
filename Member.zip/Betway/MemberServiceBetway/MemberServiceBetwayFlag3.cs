﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Member.Services
{
    public class MemberServiceBetwayFlag3 : MemberServiceBase
    {
        public MemberServiceBetwayFlag3(MemberServiceDependency memberServiceDependency) : base(memberServiceDependency)
        { }
    }
}

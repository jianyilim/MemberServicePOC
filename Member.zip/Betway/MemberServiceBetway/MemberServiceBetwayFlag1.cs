﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Member.Interfaces;
using Member.Models;
using Microsoft.AspNetCore.Mvc;

namespace Member.Services
{
    public class MemberServiceBetwayFlag1Dependency : MemberServiceDependency
    {
        public readonly IMemberRepositorySecondary _MemberRepositorySecondary;
        public MemberServiceBetwayFlag1Dependency(IMemberRepository iMemberRepository, SelfExclusionServiceBase selfExclusionService, IMemberRepositorySecondary iMemberRepositorySecondary) : base(iMemberRepository,selfExclusionService)
        {
            this._MemberRepositorySecondary = iMemberRepositorySecondary;
        }
    }
    public class MemberServiceBetwayFlag1 :MemberServiceBase
    {
        public MemberServiceBetwayFlag1(MemberServiceBetwayFlag1Dependency memberServiceBetwayFlag1Dependency) : base(memberServiceBetwayFlag1Dependency)
        {
        }
        public override bool RegisterNewMember(UserModel usermodel, out string result)
        {
            //Call base logic, which is register at Master repository
            var success = base.RegisterNewMember(usermodel, out result);

            if (success)
            {
                var memberServiceDependency = _MemberServiceDependency as MemberServiceBetwayFlag1Dependency;

                //Register at Secondary repository which is Nettium internal DB
                result = result + "\n" + memberServiceDependency._MemberRepositorySecondary.InsertNewMember(usermodel);

            }
            return success;
        }
    }
}

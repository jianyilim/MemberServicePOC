﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Member.Services
{
    public class MemberServiceBetwayFlag2 : MemberServiceBase
    {
        public MemberServiceBetwayFlag2 (MemberServiceDependency memberServiceDependency) : base(memberServiceDependency)
        { }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Member.Services
{
    public class MemberServiceBetway :MemberServiceBase
    {
        public MemberServiceBetway(MemberServiceDependency memberServiceDependency) : base(memberServiceDependency)
        { }
    }
}
